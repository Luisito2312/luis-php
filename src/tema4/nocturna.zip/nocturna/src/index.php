<?php
    require_once __DIR__  ."/vendor/autoload.php";

    use Nocturna\Controladores\HabitacionController;
    use Nocturna\Repositorios\HabitacionRepositorio;
    use Twig\Loader\FilesystemLoader;
    use Twig\Environment;

    $repo = new HabitacionRepositorio();
    $habitaciones = $repo->getAll();

    $loader = new FilesystemLoader(__DIR__ . '/Vistas');
    $twig = new Environment($loader);

    echo $twig->render('lista_habitaciones.php', [
        'habitaciones' => $habitaciones,
    ]);

    
?>