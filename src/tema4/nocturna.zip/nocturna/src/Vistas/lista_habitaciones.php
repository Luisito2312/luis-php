<!DOCTYPE html>
<html lang="es" data-bs-theme="dark">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hotel Nocturna</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" defer></script>
</head>

<body class="bg-body-tertiary text-light">

    <!-- Menú Superior -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-black border-bottom border-secondary-subtle py-3">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center gap-2 fw-bold text-uppercase" href="index.php">
                <i class="bi bi-moon-stars-fill text-danger"></i>
                NOCTURNA
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#menuNocturna" aria-controls="menuNocturna" aria-expanded="false" aria-label="Mostrar menú">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="menuNocturna">
                <ul class="navbar-nav ms-auto gap-lg-3 align-items-lg-center">
                    <li class="nav-item">
                        <a class="nav-link active fw-semibold small" href="index.php">INICIO</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link small" href="#">Registrar cliente</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link small" href="#">Consultar huéspedes</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Contenido Principal -->
    <main class="container my-5">

        <!-- Cabecera del Panel -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="h3 fw-semibold mb-0">Panel de Habitaciones</h2>
            <a href="#" class="btn btn-dark border border-secondary-subtle px-3 py-2">Nueva habitación</a>
        </div>

        <!-- Tabla de Habitaciones -->
        <div class="card bg-dark border-secondary-subtle rounded-3 shadow">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table id="tablaHabitaciones" class="table table-dark table-hover align-middle mb-0">
                        <thead>
                            <tr class="small text-secondary">
                                <th class="ps-4 py-3 text-uppercase">NÚMERO</th>
                                <th class="py-3 text-uppercase">NOMBRE</th>
                                <th class="py-3 text-uppercase">CAPACIDAD</th>
                                <th class="py-3 text-uppercase">ESTADO</th>
                                <th class="py-3 text-uppercase">PRECIO / NOCHE</th>
                                <th class="pe-4 py-3 text-end text-uppercase">ACCIONES</th>
                            </tr>
                        </thead>
                        <tbody>
                            {% for habitacion in habitaciones %}
                                <tr data-estado="{{ habitacion.isDisponible() ? 'libre' : 'ocupada' }}">
                                    <td class="ps-4 py-3 fw-bold">{{ habitacion.numero }}</td>
                                    <td class="py-3">{{ habitacion.nombre }}</td>
                                    <td class="py-3">
                                        <i class="bi bi-people-fill me-1 text-secondary"></i>
                                        {{ habitacion.capacidad }}
                                    </td>
                                    <td class="estado-celda py-3">
                                        {% if habitacion.isDisponible() %}
                                            <span class="badge bg-success px-2 py-1">Libre</span>
                                        {% else %}
                                            <span class="badge bg-danger px-2 py-1">Ocupada</span>
                                        {% endif %}
                                    </td>
                                    <td class="py-3">{{ habitacion.precio_noche }} €</td>
                                    <td class="pe-4 py-3 text-end">
                                        <div class="d-inline-flex gap-1">
                                            <button class="btn btn-sm btn-primary" onclick="cambiarEstado(this, 'ocupada')" {{ not habitacion.isDisponible() ? 'disabled' : '' }}>Reservar</button>
                                            <button class="btn btn-sm btn-outline-secondary" onclick="cambiarEstado(this, 'libre')" {{ habitacion.isDisponible() ? 'disabled' : '' }}>Liberar</button>
                                            <a href="#" class="btn btn-sm btn-info text-white">Editar</a>
                                            <button class="btn btn-sm btn-danger">Eliminar</button>
                                        </div>
                                    </td>
                                </tr>
                            {% else %}
                                <tr>
                                    <td colspan="6" class="text-center py-4 text-secondary">No hay habitaciones registradas.</td>
                                </tr>
                            {% endfor %}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>

</body>

</html>